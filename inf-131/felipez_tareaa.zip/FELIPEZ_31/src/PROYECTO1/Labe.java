package PROYECTO1;

public class Labe {

}
