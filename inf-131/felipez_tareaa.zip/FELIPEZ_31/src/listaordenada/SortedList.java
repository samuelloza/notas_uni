package listaordenada;

class SortedList {
	private Link F;

	public SortedList() {
		F = null;
	}

	public boolean isEmpty() {
		return (F == null);
	}

	public void insert(long key) {
		Link aux = new Link(key);
		Link aux2 = null;
		Link aux3 = F;

		while (aux3 != null && key > aux3.Dato) {
			aux2 = aux3;
			aux3 = aux3.next;
		}
		if (aux2 == null)
			F = aux;
		else
			aux2.next = aux;
		aux.next = aux3;
	}

	public long remove() {
		Link aux = F;
		F = F.next;
		return aux.Dato;
	}

	public void displayList() {
		Link aux3 = F;
		while (aux3 != null) {
			aux3.displayLink();
			aux3 = aux3.next;
		}
		System.out.println("");
	}
}