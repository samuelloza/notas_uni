package listaordenada;

class Main {
	public static void main(String[] args) {
		ColaPrioridad aux = new ColaPrioridad();
		aux.insert(10);
		aux.insert(9);
		aux.insert(12);
		aux.insert(0);
		aux.display();
		System.out.println(aux.remove());
		aux.display();
	}
}