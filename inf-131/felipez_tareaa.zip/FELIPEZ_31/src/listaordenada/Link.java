package listaordenada;

class Link {
	public long Dato;
	public Link next;

	public Link(long dd) {
		Dato = dd;
	}

	public void displayLink() {
		System.out.print(Dato + " ");
	}
}




