package jhimmy;


public class PilaColaD {
	protected int MAX = 100;
	protected Auto  R[]= new Auto[MAX];
}
