public class uno {
	public static void main(String[] args) {
		LinkList a = new LinkList();

		a.InsertFirst("", 2);
		a.InsertFirst("", 1);
		a.InsertLast("a", 3);
		a.InsertLast("", 4);
		a.InsertFirst("", 0);
		a.InsertLast("e", 5);
		a.displayBackwoard();
		System.out.println("...");
		System.out.println(a.buscar("e"));	
		System.out.println("....");
		a.displayBackwoard();

	}

}
