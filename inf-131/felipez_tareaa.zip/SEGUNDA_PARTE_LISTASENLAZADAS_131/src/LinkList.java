public class LinkList {
	Link F;

	public LinkList() {
		F = null;
	}

	public boolean isEmpty() {
		return F == null;
	}

	public void InsertFirst(String no, int ed) {
		Link node = new Link(no, ed);
		node.next = F;
		F = node;
	}

	public void InsertLast(String no, int ed) {
		Link node = new Link(no, ed);
		Link aux;
		aux = F;
		while (aux.next != null) {
			aux = aux.next;
		}
		aux.next = node;
	}

	public Link deleteFirst() {
		Link node = null;
		if (F == null) {
			return node;
		} else {
			node = F.next;
			F = F.next;
		}
		return node;
	}

	public Link deleteLast() {
		Link node = F;
		Link node2 = F;
		if (F == null) {
			return node;
		} else {
			while (node.next != null) {
				node = node.next;
				if (node != null) {
					node2 = node;
				}
			}
		}
		F = node2;
		return node;
	}

	public int buscar(String nom) {
		Link node = F;
		Link node2 = F;
			while (!node.Nombre.equals(nom)) {
				if (node == null) {
					return 0;
				} else {
					node2 = node;
					node = node.next;
				}
			}
			if (node==F) {
				F=F.next;
			}else {
				node2.next=node.next;
			}
			
		return node.edad;
	}

	public void displayBackwoard() {
		Link aux = F;
		while (aux != null) {
			aux.DisplayLink();
			aux = aux.next;
		}
	}
}
