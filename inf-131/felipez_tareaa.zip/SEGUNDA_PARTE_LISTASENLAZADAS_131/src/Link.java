public class Link {
	Link next;
	String Nombre;
	int edad;

	Link(String no,int ed) {
		next = null;
		Nombre = no;
		edad = ed;
	}

	public void DisplayLink() {
		System.out.println(Nombre + " " + edad);
	}

	public int getEdada() {
		return edad;
	}

	public String getNombre() {
		return Nombre;
	}
}
