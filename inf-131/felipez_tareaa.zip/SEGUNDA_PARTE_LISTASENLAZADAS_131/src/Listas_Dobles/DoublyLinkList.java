package Listas_Dobles;

public class DoublyLinkList {
	Link F;
	Link L;

	public DoublyLinkList() {
		F = null;
		L = null;
	}

	public boolean isEmpty() {
		return F == null;
	}

	public void insertFirst(int x) {
		Link node = new Link(x);
		if (isEmpty()) {
			L = node;
		} else {
			F.prev = node;
		}
		node.next = F;
		F = node;
	}

	public void insertLast(int x) {
		Link node = new Link(x);
		if (isEmpty()) {
			F = node;
		} else {
			L.next = node;
			node.prev = L;
		}
		L = node;
	}

	public int deleteFirst() {
		Link aux = F;
		if (F.next == null) {
			L = null;
		} else {
			F.next.prev = null;
		}
		F = F.next;
		return aux.dato;
	}

	public int deleteLast() {
		Link aux = L;
		if (F.prev == null) {
			F = null;
		} else {
			L.next.prev = null;
		}
		F = F.next;
		return aux.dato;
	}

	public int insertAntes(int bus, int dd) {
		Link aux = F;
		while (aux.dato != bus) {
			if (aux == null) {
				return 0;
			} else {
				aux = aux.next;
			}
		}
		Link node = new Link(dd);
		if (aux == F) {
			//aux.next = F;
		}
	//	F.next = aux;
		//F.next.prev = aux;

		return aux.dato;
	}

	public void displayBackworad() {
		Link aux = F;
		while (aux != null) {
			aux.displayLink();
			aux = aux.next;

		}
	}
}
