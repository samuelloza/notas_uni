package Listas_Dobles;

public class Link {
	Link next;
	Link prev;
	int dato;

	public Link(int d) {
		next = null;
		prev = null;
		dato = d;
	}

	public void displayLink() {
		System.out.println(dato);
	}

}
