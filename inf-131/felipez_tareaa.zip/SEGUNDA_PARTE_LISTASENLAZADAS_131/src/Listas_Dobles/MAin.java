package Listas_Dobles;
public class MAin {
	public static void main(String[] args) {
		DoublyLinkList aux = new DoublyLinkList();
		aux.insertFirst(3);
		aux.insertFirst(2);
		aux.insertFirst(1);
//		aux.insertLast(4);
//		aux.insertLast(5);
//		aux.insertLast(6);
	aux.insertAntes(1,123);
		aux.displayBackworad();

	}

}
