package listaordenada;

public class ColaPrioridad {
	SortedList aux;

	public ColaPrioridad() {
		aux = new SortedList();
	}

	public void insert(long x) {
		aux.insert(x);
	}

	public long remove() {
		return aux.remove();
	}

	public void display() {
		aux.displayList();
	}
}
